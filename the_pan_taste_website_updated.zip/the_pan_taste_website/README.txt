THE PAN TASTE WEBSITE — UPDATED FILES

Included:
- index.html: responsive website with expanded online-menu highlights
- shop-photo.jpg: a real shop photo extracted from the video you shared

Publish with GitHub Pages:
1. Download and extract this ZIP.
2. On GitHub, create a PUBLIC repository named the-pan-taste.
3. Upload BOTH index.html and shop-photo.jpg (not the ZIP itself).
4. Commit the upload.
5. Open Settings > Pages.
6. Under Build and deployment, select Deploy from a branch; branch main; folder /(root); Save.
7. Wait a few minutes and open the live address shown under Settings > Pages.

Important:
- Menu items/prices are based on the outlet's online listing and should be confirmed by the shop owner before public launch.
- Contact number/address are from the business listing/shared map link; confirm with the owner.
- This is a static info website; it does not process payments or manage orders.
